package com.nikhil.persistence;

public interface OrderDao {

}
