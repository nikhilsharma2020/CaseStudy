package com.nikhil.service;

public interface OrderService {

}
